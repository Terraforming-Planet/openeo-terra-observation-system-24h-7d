TerraObserver public CDSE audit. Python 3.10+.
Run: python -B -m terraobserver.cdse --output /tmp/new-cdse-audit
Tests: python -B -m unittest discover -s tests -v
No private models, credentials or paid job execution are included.
